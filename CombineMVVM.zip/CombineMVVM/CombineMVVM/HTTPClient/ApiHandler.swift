//
//  ApiHandler.swift
//  CombineMVVM
//
//  Created by Apple on 09/01/24.
//

import Foundation
import Combine

enum NetworkError: Error{
    
    case invaliUrl
    case networkError
}

class Apimanager{
    
    static let shared = Apimanager()
    
    private init(){
        
    }
    
    private var bag = Set<AnyCancellable>()

    
    func getProductsData(completionHandler: @escaping(Result<[Product],NetworkError>)->Void){
        
        guard let url = URL(string: "https://fakestoreapi.com/products") else{
            
          return
            
        }
        URLSession.shared.dataTaskPublisher(for: url)
            .receive(on: DispatchQueue.main)
            .map(\.data)
            .decode(type: [Product].self, decoder: JSONDecoder())
            .sink { res in
                
                
            } receiveValue: {  productsdata in
                
                completionHandler(.success(productsdata))
                
//                self?.products = productsdata
                
//                print(self?.products.count ?? "")
            }
            .store(in: &bag)


        
    }

    

}
